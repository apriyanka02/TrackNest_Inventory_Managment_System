package com.zsgs.tracknest.features.user;

import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.data.repository.TrackNestDB;

import java.util.List;

class UserListModel {

    List<User> getUsers() {
        return TrackNestDB.getInstance().getUsers();
    }

    User getUser(Long userId) {
        return TrackNestDB.getInstance().getUserById(userId);
    }
}
