package com.zsgs.tracknest.features.user;

import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class UserListView {

    private final UserListModel userListModel;
    private final Scanner scanner;

    public UserListView() {
        this.userListModel = new UserListModel();
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("User Management");
        System.out.println("1. View all users");
        System.out.println("2. View user");
        System.out.print("Choose an option: ");
        if ("2".equals(scanner.nextLine().trim())) {
            showUser();
        } else {
            showAllUsers();
        }
    }

    private void showAllUsers() {
        List<User> users = userListModel.getUsers();
        printLine("All Users");
        if (users.isEmpty()) {
            System.out.println("No users found.");
        } else {
            for (User user : users) {
                printUser(user);
            }
        }
        printLine("End of Users");
    }

    private void showUser() {
        System.out.print("Enter user id: ");
        User user = userListModel.getUser(readLong());
        printLine("User Details");
        if (user == null) {
            System.out.println("User not found.");
        } else {
            printUser(user);
        }
        printLine("End of User Details");
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void printUser(User user) {
        System.out.println(user.getUserId() + ". " + user.getUserName()
                + " | " + user.getEmail()
                + " | " + user.getRole());
    }

    private void printLine(String title) {
        System.out.println("========== " + title + " ==========");
    }
}
