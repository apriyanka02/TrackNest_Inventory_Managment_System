package com.zsgs.tracknest.features.stock;

import com.zsgs.tracknest.data.dto.StockTransaction;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class StockView {

    private final StockModel stockModel;
    private final Scanner scanner;

    public StockView() {
        this.stockModel = new StockModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        StockTransaction transaction = new StockTransaction();
        System.out.print("Enter product id: ");
        transaction.setProductId(readLong());
        System.out.print("Enter supplier id (optional, press Enter for none): ");
        transaction.setSupplierId(readOptionalLong());
        System.out.print("Enter quantity: ");
        transaction.setQuantity(readLong());
        System.out.print("Enter price: ");
        transaction.setPrice(readLong());
        System.out.println("1. Stock In");
        System.out.println("2. Stock Out");
        System.out.print("Choose transaction type: ");
        transaction.setTransactionType("2".equals(scanner.nextLine().trim())
                ? StockTransaction.TransactionType.STOCK_OUT
                : StockTransaction.TransactionType.STOCK_IN);
        stockModel.recordTransaction(transaction);
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Long readOptionalLong() {
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) return null;
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    void onStockTransactionRecorded(StockTransaction transaction) {
        System.out.println("Stock transaction recorded with id: " + transaction.getTransactionId());
    }

    void onStockTransactionFailed(String message) {
        System.out.println(message);
    }
}
