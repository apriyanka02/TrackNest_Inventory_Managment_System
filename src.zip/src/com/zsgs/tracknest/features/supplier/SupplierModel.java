package com.zsgs.tracknest.features.supplier;

import com.zsgs.tracknest.data.dto.Supplier;
import com.zsgs.tracknest.data.repository.TrackNestDB;

import java.util.List;

class SupplierModel {

    Supplier addSupplier(Supplier supplier) {
        return TrackNestDB.getInstance().addSupplier(supplier);
    }

    List<Supplier> getSuppliers() {
        return TrackNestDB.getInstance().getSuppliers();
    }

    Supplier getSupplier(Long supplierId) {
        return TrackNestDB.getInstance().getSupplierById(supplierId);
    }
}
