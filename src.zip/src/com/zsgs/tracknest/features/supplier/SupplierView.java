package com.zsgs.tracknest.features.supplier;

import com.zsgs.tracknest.data.dto.Supplier;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class SupplierView {

    private final SupplierModel supplierModel;
    private final Scanner scanner;

    public SupplierView() {
        this.supplierModel = new SupplierModel();
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println();
        System.out.println("Supplier Management");
        System.out.println("1. Add supplier");
        System.out.println("2. View all suppliers");
        System.out.println("3. View supplier");
        System.out.print("Choose an option: ");
        switch (scanner.nextLine().trim()) {
            case "1":
                addSupplier();
                break;
            case "3":
                showSupplier();
                break;
            default:
                showSuppliers();
                break;
        }
    }

    public void addSupplier() {
        Supplier supplier = new Supplier();
        System.out.print("Enter supplier name: ");
        supplier.setSupplierName(scanner.nextLine().trim());
        System.out.print("Enter address: ");
        supplier.setAddress(scanner.nextLine().trim());
        Supplier saved = supplierModel.addSupplier(supplier);
        System.out.println(saved == null ? "Could not add supplier." : "Supplier added with id: " + saved.getSupplierId());
    }

    public void showSuppliers() {
        List<Supplier> suppliers = supplierModel.getSuppliers();
        printLine("All Suppliers");
        if (suppliers.isEmpty()) {
            System.out.println("No suppliers found.");
        } else {
            for (Supplier supplier : suppliers) {
                printSupplier(supplier);
            }
        }
        printLine("End of Suppliers");
    }

    public void showSupplier() {
        System.out.print("Enter supplier id: ");
        Supplier supplier = supplierModel.getSupplier(readLong());
        printLine("Supplier Details");
        if (supplier == null) {
            System.out.println("Supplier not found.");
        } else {
            printSupplier(supplier);
        }
        printLine("End of Supplier Details");
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void printSupplier(Supplier supplier) {
        System.out.println(supplier.getSupplierId() + ". " + supplier.getSupplierName()
                + " | " + supplier.getAddress());
    }

    private void printLine(String title) {
        System.out.println("========== " + title + " ==========");
    }
}
