package com.zsgs.tracknest.features.signin;

import com.zsgs.tracknest.data.dto.LoginRequest;
import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.data.repository.TrackNestDB;

class SignInModel {

    private final SignInView signInView;

    SignInModel(SignInView signInView) {
        this.signInView = signInView;
    }

    void authenticate(LoginRequest request) {
        if (request == null || isBlank(request.getEmail()) || isBlank(request.getPassword())) {
            signInView.onSignInFailed("Email and password are required.");
            return;
        }

        User user = TrackNestDB.getInstance().authenticateUser(request.getEmail(), request.getPassword());
        if (user == null) {
            signInView.onSignInFailed("Invalid email or password.");
            return;
        }
        signInView.onSignInSuccessful(user);
    }

    void register(User user) {
        if (user == null
                || isBlank(user.getUserName())
                || isBlank(user.getEmail())
                || isBlank(user.getPassword())) {
            signInView.onSignInFailed("Name, email and password are required.");
            return;
        }
        if (TrackNestDB.getInstance().getUserByEmail(user.getEmail()) != null) {
            signInView.onSignInFailed("This email is already registered. Please sign in.");
            return;
        }

        user.setEmail(user.getEmail().trim());
        user.setUserName(user.getUserName().trim());
        user.setRole(User.Role.USER);
        User savedUser = TrackNestDB.getInstance().addUser(user);
        if (savedUser == null) {
            signInView.onSignInFailed("Could not create user.");
            return;
        }
        signInView.onSignInSuccessful(savedUser);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
