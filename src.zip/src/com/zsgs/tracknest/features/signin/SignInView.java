package com.zsgs.tracknest.features.signin;

import com.zsgs.tracknest.data.dto.LoginRequest;
import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.features.home.HomeView;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class SignInView {

    private final SignInModel signInModel;
    private final Scanner scanner;
    private boolean authenticated;

    public SignInView() {
        this.signInModel = new SignInModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        while (true) {
            System.out.println();
            System.out.println("TrackNest Account");
            System.out.println("1. Already a user");
            System.out.println("2. New user");
            System.out.println("3. Back");
            System.out.print("Choose an option: ");
            switch (scanner.nextLine().trim()) {
                case "1":
                    showSignIn();
                    if (authenticated) return;
                    break;
                case "2":
                    registerUser();
                    if (authenticated) return;
                    break;
                case "3":
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void showSignIn() {
        System.out.println();
        System.out.println("Sign in to TrackNest");
        while (!authenticated) {
            promptAndAuthenticate();
            if (authenticated) return;
            if (!promptRetry()) return;
        }
    }

    private void promptAndAuthenticate() {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        LoginRequest request = new LoginRequest();
        request.setEmail(email == null ? null : email.trim());
        request.setPassword(password);
        signInModel.authenticate(request);
    }

    private void registerUser() {
        System.out.println();
        System.out.println("Create TrackNest Account");
        User user = new User();
        System.out.print("Enter your name: ");
        user.setUserName(scanner.nextLine());
        System.out.print("Enter your email: ");
        user.setEmail(scanner.nextLine());
        System.out.print("Enter your password: ");
        user.setPassword(scanner.nextLine());
        System.out.print("Enter phone number: ");
        user.setPhoneNumber(readLong());
        System.out.print("Enter place: ");
        user.setPlace(scanner.nextLine().trim());
        signInModel.register(user);
    }

    private boolean promptRetry() {
        System.out.println();
        System.out.println("1. Retry");
        System.out.println("2. Exit");
        System.out.print("Choose an option: ");
        return "1".equals(scanner.nextLine().trim());
    }

    void onSignInSuccessful(User user) {
        authenticated = true;
        System.out.println("Welcome, " + user.getUserName());
        new HomeView(user).init();
    }

    void onSignInFailed(String message) {
        System.out.println(message);
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
