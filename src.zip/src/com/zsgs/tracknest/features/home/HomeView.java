package com.zsgs.tracknest.features.home;

import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.features.order.OrderView;
import com.zsgs.tracknest.features.product.ProductListView;
import com.zsgs.tracknest.features.product.add.ProductAddView;
import com.zsgs.tracknest.features.product.details.ProductDetailsView;
import com.zsgs.tracknest.features.product.update.ProductUpdateView;
import com.zsgs.tracknest.features.report.ReportView;
import com.zsgs.tracknest.features.stock.StockView;
import com.zsgs.tracknest.features.supplier.SupplierView;
import com.zsgs.tracknest.features.user.UserListView;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class HomeView {

    private final HomeModel homeModel;
    private final User user;
    private final Scanner scanner;

    public HomeView(User user) {
        this.homeModel = new HomeModel(this);
        this.user = user;
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        homeModel.init(user);
    }

    void showUnauthorized() {
        System.out.println("Your account role is not set. Contact your administrator.");
    }

    void showAdminMenu() {
        while (true) {
            System.out.println();
            System.out.println("Admin Home");
            System.out.println("1.  Add supplier");
            System.out.println("2.  View suppliers");
            System.out.println("3.  View users");
            System.out.println("4.  Add new product");
            System.out.println("5.  View products");
            System.out.println("6.  View product details");
            System.out.println("7.  Update product details");
            System.out.println("8.  Stock management");
            System.out.println("9.  Supplier transactions");
            System.out.println("10. Order management");
            System.out.println("11. Reports");
            System.out.println("12. Sign out");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    new SupplierView().addSupplier();
                    break;
                case "2":
                    new SupplierView().showSuppliers();
                    break;
                case "3":
                    new UserListView().init();
                    break;
                case "4":
                    new ProductAddView().init();
                    break;
                case "5":
                    new ProductListView().init();
                    break;
                case "6":
                    new ProductDetailsView().init();
                    break;
                case "7":
                    new ProductUpdateView().init();
                    break;
                case "8":
                case "9":
                    new StockView().init();
                    break;
                case "10":
                    new OrderView(user).init();
                    break;
                case "11":
                    new ReportView().init();
                    break;
                case "12":
                    System.out.println("You have been signed out.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    void showUserMenu() {
        while (true) {
            System.out.println();
            System.out.println("User Home");
            System.out.println("1. View/search products");
            System.out.println("2. Create order");
            System.out.println("3. View order history");
            System.out.println("4. Sign out");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    new ProductListView().init();
                    break;
                case "2":
                case "3":
                    new OrderView(user).init();
                    break;
                case "4":
                    System.out.println("You have been signed out.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
