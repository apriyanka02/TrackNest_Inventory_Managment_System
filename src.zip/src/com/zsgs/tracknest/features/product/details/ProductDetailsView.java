package com.zsgs.tracknest.features.product.details;

import com.zsgs.tracknest.data.dto.Product;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class ProductDetailsView {

    private final ProductDetailsModel productDetailsModel;
    private final Scanner scanner;

    public ProductDetailsView() {
        this.productDetailsModel = new ProductDetailsModel();
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.print("Enter product id: ");
        Product product = productDetailsModel.getProduct(readLong());
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        System.out.println("Name: " + product.getProductName());
        System.out.println("Price: " + product.getPrice());
        System.out.println("Quantity: " + product.getQuantity());
        System.out.println("Status: " + product.getStatus());
        System.out.println("Manufactured Date: " + product.getManufacturedDate());
        System.out.println("Expiry Date: " + product.getExpiryDate());
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
