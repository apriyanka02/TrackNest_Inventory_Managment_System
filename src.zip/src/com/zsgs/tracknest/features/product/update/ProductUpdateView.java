package com.zsgs.tracknest.features.product.update;

import com.zsgs.tracknest.data.dto.Product;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class ProductUpdateView {

    private final ProductUpdateModel productUpdateModel;
    private final Scanner scanner;

    public ProductUpdateView() {
        this.productUpdateModel = new ProductUpdateModel();
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.print("Enter product id: ");
        Long productId = readLong();
        Product product = productUpdateModel.getProduct(productId);
        if (product == null) {
            System.out.println("Product not found.");
            return;
        }
        System.out.println("1. Update price");
        System.out.println("2. Update quantity");
        System.out.println("3. Delete product");
        System.out.print("Choose an option: ");
        String choice = scanner.nextLine().trim();
        if ("1".equals(choice)) {
            System.out.print("Enter new price: ");
            product.setPrice(readLong());
            productUpdateModel.updateProduct(product);
            System.out.println("Product price updated.");
        } else if ("2".equals(choice)) {
            System.out.print("Enter new quantity: ");
            product.setQuantity(readLong());
            productUpdateModel.updateProduct(product);
            System.out.println("Product quantity updated.");
        } else if ("3".equals(choice)) {
            System.out.println(productUpdateModel.deleteProduct(productId) ? "Product deleted." : "Could not delete product.");
        } else {
            System.out.println("Invalid option.");
        }
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
