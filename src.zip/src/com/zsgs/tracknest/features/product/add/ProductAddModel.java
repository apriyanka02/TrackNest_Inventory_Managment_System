package com.zsgs.tracknest.features.product.add;

import com.zsgs.tracknest.data.dto.Product;
import com.zsgs.tracknest.data.repository.TrackNestDB;

class ProductAddModel {

    private final ProductAddView productAddView;

    ProductAddModel(ProductAddView productAddView) {
        this.productAddView = productAddView;
    }

    void addProduct(Product product) {
        Product saved = TrackNestDB.getInstance().addProduct(product);
        if (saved == null) {
            productAddView.onProductAddFailed("Could not add product.");
            return;
        }
        productAddView.onProductAdded(saved);
    }
}
