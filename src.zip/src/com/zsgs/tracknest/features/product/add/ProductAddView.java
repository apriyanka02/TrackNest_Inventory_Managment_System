package com.zsgs.tracknest.features.product.add;

import com.zsgs.tracknest.data.dto.Product;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

public class ProductAddView {

    private final ProductAddModel productAddModel;
    private final Scanner scanner;

    public ProductAddView() {
        this.productAddModel = new ProductAddModel(this);
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        Product product = new Product();
        System.out.print("Enter product name: ");
        product.setProductName(scanner.nextLine().trim());
        System.out.print("Enter price: ");
        product.setPrice(readLong());
        System.out.print("Enter quantity: ");
        product.setQuantity(readLong());
        productAddModel.addProduct(product);
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    void onProductAdded(Product product) {
        System.out.println("Product added with id: " + product.getProductId());
    }

    void onProductAddFailed(String message) {
        System.out.println(message);
    }
}
