package com.zsgs.tracknest.features.report;

import com.zsgs.tracknest.data.repository.TrackNestDB;

class ReportModel {

    int getProductCount() {
        return TrackNestDB.getInstance().getProducts().size();
    }

    int getOrderCount() {
        return TrackNestDB.getInstance().getOrders().size();
    }

    int getSupplierCount() {
        return TrackNestDB.getInstance().getSuppliers().size();
    }
}
