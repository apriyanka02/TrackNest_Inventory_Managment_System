package com.zsgs.tracknest.features.report;

public class ReportView {

    private final ReportModel reportModel;

    public ReportView() {
        this.reportModel = new ReportModel();
    }

    public void init() {
        System.out.println("Inventory Report");
        System.out.println("Products: " + reportModel.getProductCount());
        System.out.println("Suppliers: " + reportModel.getSupplierCount());
        System.out.println("Orders: " + reportModel.getOrderCount());
    }
}
