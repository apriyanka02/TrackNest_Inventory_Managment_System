package com.zsgs.tracknest.features.order;

import com.zsgs.tracknest.data.dto.Order;
import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.List;
import java.util.Scanner;

public class OrderView {

    private final OrderModel orderModel;
    private final User user;
    private final Scanner scanner;

    public OrderView(User user) {
        this.orderModel = new OrderModel();
        this.user = user;
        this.scanner = ConsoleInput.getScanner();
    }

    public void init() {
        System.out.println("1. Create order");
        System.out.println("2. View orders");
        System.out.print("Choose an option: ");
        if ("1".equals(scanner.nextLine().trim())) {
            createOrder();
        } else {
            showOrders();
        }
    }

    private void createOrder() {
        System.out.print("Enter product id: ");
        Long productId = readLong();
        System.out.print("Enter quantity: ");
        int quantity = readInt();
        Order order = orderModel.createOrder(user == null ? null : user.getUserId(), productId, quantity);
        System.out.println(order == null ? "Could not create order." : "Order created with id: " + order.getOrderId());
    }

    private void showOrders() {
        boolean allOrders = user != null && user.getRole() == User.Role.ADMIN;
        List<Order> orders = orderModel.getOrders(user == null ? null : user.getUserId(), allOrders);
        printLine(allOrders ? "All Orders" : "Your Orders");
        if (orders.isEmpty()) {
            System.out.println("No orders found.");
        } else {
            for (Order order : orders) {
                User buyer = orderModel.getUser(order.getUserId());
                System.out.println(order.getOrderId() + ". Buyer: " + formatBuyer(buyer, order.getUserId())
                        + " | Total: " + order.getTotalPrice()
                        + " | Status: " + order.getStatus());
            }
        }
        printLine("End of Orders");
    }

    private Long readLong() {
        try {
            return Long.parseLong(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private int readInt() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String formatBuyer(User buyer, Long userId) {
        if (buyer == null) return "Unknown user " + userId;
        return buyer.getUserName() + " (" + buyer.getEmail() + ")";
    }

    private void printLine(String title) {
        System.out.println("========== " + title + " ==========");
    }
}
