package com.zsgs.tracknest.features.order;

import com.zsgs.tracknest.data.dto.Order;
import com.zsgs.tracknest.data.dto.OrderedItem;
import com.zsgs.tracknest.data.dto.Product;
import com.zsgs.tracknest.data.dto.User;
import com.zsgs.tracknest.data.repository.TrackNestDB;

import java.util.List;

class OrderModel {

    Product getProduct(Long productId) {
        return TrackNestDB.getInstance().getProductById(productId);
    }

    Order createOrder(Long userId, Long productId, int quantity) {
        Product product = getProduct(productId);
        if (product == null || product.getPrice() == null || quantity <= 0) return null;

        Order order = new Order();
        order.setUserId(userId);
        order.setTotalPrice(product.getPrice() * quantity);
        Order savedOrder = TrackNestDB.getInstance().addOrder(order);
        if (savedOrder == null) return null;

        OrderedItem item = new OrderedItem();
        item.setOrderId(savedOrder.getOrderId());
        item.setProductId(productId);
        item.setQuantity(quantity);
        TrackNestDB.getInstance().addOrderedItem(item);
        return savedOrder;
    }

    List<Order> getOrders(Long userId, boolean allOrders) {
        if (allOrders) return TrackNestDB.getInstance().getOrders();
        return TrackNestDB.getInstance().getOrdersByUser(userId);
    }

    User getUser(Long userId) {
        return TrackNestDB.getInstance().getUserById(userId);
    }
}
