package com.zsgs.tracknest;

import com.zsgs.tracknest.features.signin.SignInView;
import com.zsgs.tracknest.util.ConsoleInput;

import java.util.Scanner;

class TrackNestApplication {

    public static final int VERSION_NO = 1;
    public static final String VERSION_NAME = "1.0.0";

    public static void main(String[] args) {
        System.out.println("Welcome to TrackNest");
        System.out.println("Version " + VERSION_NAME);
        showLandingMenu();
    }

    private static void showLandingMenu() {
        Scanner scanner = ConsoleInput.getScanner();
        while (true) {
            System.out.println();
            System.out.println("1. Sign In");
            System.out.println("2. Exit");
            System.out.print("Choose an option: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    new SignInView().init();
                    break;
                case "2":
                    System.out.println("Thank you for using TrackNest");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
